#!/bin/bash
./magic_transformer agent_performance:stdout state_rating:stdout agent_rating:stdout state_performance:stderr
