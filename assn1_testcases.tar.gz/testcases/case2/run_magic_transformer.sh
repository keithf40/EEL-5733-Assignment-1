#!/bin/bash
./magic_transformer
