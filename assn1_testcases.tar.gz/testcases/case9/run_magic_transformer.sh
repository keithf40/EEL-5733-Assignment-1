#!/bin/bash
./magic_transformer state_performance:stdout state_rating:stdout agent_rating:stderr agent_performance:stdout
