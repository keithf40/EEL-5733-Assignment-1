#!/bin/bash
./magic_transformer agent_performance:stdout
