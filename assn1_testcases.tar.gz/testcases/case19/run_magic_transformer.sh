#!/bin/bash
./magic_transformer state_rating:stderr agent_rating:stdout agent_performance:stderr
