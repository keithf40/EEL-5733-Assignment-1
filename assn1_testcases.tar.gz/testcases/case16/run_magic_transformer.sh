#!/bin/bash
./magic_transformer agent_rating:stdout agent_performance:stderr state_rating:stdout
