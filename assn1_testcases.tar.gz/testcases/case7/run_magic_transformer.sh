#!/bin/bash
./magic_transformer agent_performance:stderr state_performance:stderr
