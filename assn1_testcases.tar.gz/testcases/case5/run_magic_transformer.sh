#!/bin/bash
./magic_transformer state_performance:stderr state_rating:stderr
