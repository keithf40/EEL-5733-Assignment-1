#!/bin/bash
./magic_transformer agent_rating:stderr state_performance:stdout agent_performance:stderr state_rating:stderr
