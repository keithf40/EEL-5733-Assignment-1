#!/bin/bash
./magic_transformer state_performance:stdout state_rating:stderr agent_performance:stderr agent_rating:stdout
