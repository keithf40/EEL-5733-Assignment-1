#!/bin/bash
./magic_transformer state_performance:stderr agent_performance:stderr agent_rating:stderr state_rating:stdout agent_performance:stdout
