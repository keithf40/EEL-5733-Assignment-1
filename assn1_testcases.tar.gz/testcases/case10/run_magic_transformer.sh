#!/bin/bash
./magic_transformer agent_performance:stdout state_performance:stderr agent_rating:stdout state_rating:stderr agent_performance:stderr
