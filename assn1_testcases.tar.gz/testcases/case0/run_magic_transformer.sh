#!/bin/bash
./magic_transformer state_performance:stderr state_rating:stdout agent_performance:stdout agent_rating:stderr
