#!/bin/bash
./magic_transformer state_performance:stderr agent_rating:stderr agent_performance:stderr
